package test;
/*
 * For testing all the Functions : UNIT TESTING
 */
import org.junit.runner.RunWith; 
import org.junit.runners.Suite; 


@RunWith(Suite.class) 
@Suite.SuiteClasses({ InitiateTransactionTest.class, ValidateInputFileTest.class }) 
public class TestSuite { }
